const express = require('express');
const app = express();
const fs = require('fs');
const port = 3000;
const path = require('path');
const ejs = require('ejs');
const bodyParser = require('body-parser');
const multer = require('multer');
const mysql = require('mysql2');
const OneDay = 1000 * 60 * 60 * 24;
const session = require('express-session');
const cookieParser = require('cookie-parser');

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static('public'));
app.use(session({
  secret: 'your_secret_key',
  resave: true,
  saveUninitialized: true,
}));
app.use(cookieParser());

function checkAuthentication(req, res, next) {
  if (req.cookies.authenticated === 'true' && req.cookies.username) {
    req.session.authenticated = true;
    req.session.username = req.cookies.username;
  }

  if (req.session.authenticated) {
    next();
  } else {
    res.redirect('/register');
  }
}

const connection = mysql.createConnection({
  host: '192.168.1.161',
  user: 'adam.rosch',
  password: 'Roschambo12',
  database: 'arcade',
  port: 3001,
});

const storage = multer.memoryStorage();
const upload = multer({
  storage: storage,
  limits: { fileSize: 1000 * 1920 * 1080 },
});

app.get('/register', (req, res) => {
  res.render('register.ejs');
});

app.post('/register', (req, res) => {
  const { username, password } = req.body;

  // Zkontrolujte, zda uživatelské jméno již existuje v databázi
  connection.query('SELECT * FROM uzivatele WHERE BINARY username = ?', [username], (error, results, fields) => {
    if (error) {
      console.error(error);
      res.status(500).send('Chyba při registraci.');
    } else {
      if (results.length > 0) {
        res.send('Uživatelské jméno již existuje. Vyberte si prosím jiné.');
      } else {
        // Uživatelské jméno je unikátní, můžeme vytvořit účet
        connection.query('INSERT INTO uzivatele (username, password) VALUES (?, ?)', [username, password], (error, results, fields) => {
          if (error) {
            console.error(error);
            res.status(500).send('Chyba při registraci.');
          } else {
            console.log('Uživatel byl úspěšně registrován.');
            res.redirect('/login');
          }
        });
      }
    }
  });
});

app.get('/login', (req, res) => {
  res.render('login.ejs');
});

app.post('/login', (req, res) => {
  const { username, password } = req.body;

  connection.query('SELECT * FROM uzivatele WHERE BINARY username = ? AND BINARY password = ?', [username, password], (error, results, fields) => {
    if (error) {
      console.error(error);
      res.status(500).send('Chyba při přihlášení.');
    } else {
      if (results.length > 0) {
        req.session.authenticated = true;
        req.session.username = username;
        res.cookie('username', username, { maxAge: OneDay });
        res.cookie('authenticated', true, { maxAge: OneDay });
        res.redirect('/main');
      } else {
        res.send('Nesprávné uživatelské jméno nebo heslo.');
      }
    }
  });
});

app.get('/main', (req, res) => {
  if (req.session.authenticated) {
    const loggedInUserName = req.session.username;

    connection.query('SELECT * FROM hentai', (error, results, fields) => {
      if (error) {
        console.error(error);
        return;
      }
      res.render('main.ejs', { results, loggedInUserName });
    });
  } else {
    res.redirect('/register');
  }
});

app.get('/galerie', (req, res) => {
  if (req.session.authenticated) {
    connection.query('SELECT test FROM hentai', (error, results, fields) => {
      if (error) {
        console.error(error);
        res.status(500).send('Chyba při načítání obrázků.');
      } else {
        res.render('galerie.ejs', { images: results });
      }
    });
  } else {
    res.redirect('/register');
  }
});

app.get('/dino', (req, res) => {
  if (req.session.authenticated) {
    res.render('dino');
  } else {
    res.redirect('/register');
  }
});

app.get('/upload', checkAuthentication, (req, res) => {
  res.render('upload.ejs');
});

app.post('/upload', checkAuthentication, upload.single('image'), (req, res) => {
  const imageBuffer = req.file.buffer;
  const nameValue = req.body.name;

  connection.query('INSERT INTO hentai (Name, test) VALUES (?, ?)', [nameValue, imageBuffer], (error, results, fields) => {
    if (error) {
      console.error(error);
      res.status(500).send('Chyba při ukládání obrázku.');
    } else {
      console.log('Obrázek byl úspěšně uložen do databáze.');
      res.redirect('/main');
    }
  });
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});